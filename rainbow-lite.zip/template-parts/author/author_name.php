<h1 class="author-name">
    <?php the_author(); ?>
</h1>