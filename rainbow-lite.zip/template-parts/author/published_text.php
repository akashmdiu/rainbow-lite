<span class="author-post-count">
    <strong><?php echo get_the_author(); ?></strong> <?php echo esc_html(str_replace('[count]', do_shortcode( '[count]'), get_theme_mod('RB_published_text_settings'))); ?>
</span>