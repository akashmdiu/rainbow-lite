<?php if (get_the_author_meta('description')) : ?>
    <p class="author-bio"><?php echo get_the_author_meta('description'); ?></p>
<?php endif; ?>