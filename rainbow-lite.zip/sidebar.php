<div class="col-lg-3 col-md-5">
    <div class="rainbow-sidebar">
        <?php if (is_active_sidebar('rainbow-sidebar')) :
            dynamic_sidebar('rainbow-sidebar');
        endif; ?>
    </div>
</div>